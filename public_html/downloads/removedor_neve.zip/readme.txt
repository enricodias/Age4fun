ReMove SnoW V1.0

This mod will replace snow with default terrain. 
Note that Buildings, Forests, MINIMAP etc will still appear snow covered.

If you want to uninstall this mod either relpace terrain.drs 
with terrain.old (will be created during install) or reinstall your game.


How to install:
copy/extract the drsbuild.exe and removesnow.bat 
into your \AoK\Data\ folder and run removesnow.bat



ReMove SnoW Script
Copyright (C) 2000 pG_plexiq_  

(.DRS) Builder Utility 
Copyright (C) 1997 Stoyan Ratchev

http://www.pro-gaming.de